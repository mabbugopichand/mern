const express = require("express");
const mongoose = require("mongoose");
const axios = require("axios");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

const PORT = 5000;
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/mern_ai_db";

mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const ChatSchema = new mongoose.Schema({
  message: String,
  response: String,
});

const Chat = mongoose.model("Chat", ChatSchema);

app.post("/chat", async (req, res) => {
  const { message } = req.body;

  try {
    const aiResponse = await axios.post("http://ai-service:8000/ask", {
      message,
    });

    const chat = new Chat({
      message,
      response: aiResponse.data.response,
    });

    await chat.save();

    res.json({ response: aiResponse.data.response });
  } catch (error) {
    console.error(error);
    res.status(500).send("AI service error");
  }
});

app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT}`);
});