import React, { useState } from "react";
import axios from "axios";

function App() {
  const [userInput, setUserInput] = useState("");
  const [response, setResponse] = useState("");

  const handleInputChange = (e) => {
    setUserInput(e.target.value);
  };

  const handleSend = async () => {
    try {
      const res = await axios.post("http://localhost:5000/chat", {
        message: userInput,
      });
      setResponse(res.data.response);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Simple AI Chatbot</h1>
      <textarea
        placeholder="Type your message..."
        value={userInput}
        onChange={handleInputChange}
        rows="4"
        cols="50"
      />
      <br />
      <button onClick={handleSend}>Send</button>
      <div>
        <h3>Response:</h3>
        <p>{response}</p>
      </div>
    </div>
  );
}

export default App;