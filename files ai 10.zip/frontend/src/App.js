import React, { useState, useEffect } from 'react';

function App() {
  const [text, setText] = useState('');
  const [data, setData] = useState([]);
  
  const fetchData = async () => {
    const response = await fetch('http://localhost:5000/data');
    const result = await response.json();
    setData(result);
  };

  const handleAnalyze = async () => {
    const response = await fetch('http://localhost:5000/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
    const result = await response.json();
    setText('');
    fetchData();
    alert(`Sentiment Score: ${result.sentimentScore}`);
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h1>AI Sentiment Analysis</h1>
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter text"
        style={{ width: '300px', marginRight: '10px' }}
      />
      <button onClick={handleAnalyze}>Analyze</button>
      <h2>Data:</h2>
      <ul>
        {data.map((item, index) => (
          <li key={index}>
            {item.text} - Score: {item.sentimentScore}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;