# MERN AI Sentiment Analysis App

## Description
This is a simple MERN stack application that integrates an AI-based sentiment analysis feature. The application allows users to input text, analyze its sentiment, and store the data in a MongoDB database.

## Prerequisites
- Docker and Docker Compose installed on your machine.

## Setup Instructions
1. Clone this repository:
   ```bash
   git clone https://github.com/your-repo/mern-ai-app.git
   cd mern-ai-app
   ```

2. Start the application using Docker Compose:
   ```bash
   docker-compose up
   ```

3. Access the frontend at [http://localhost:3000](http://localhost:3000).

## Project Structure
- **frontend/**: React application code.
- **backend/**: Express.js server code.
- **docker-compose.yml**: Docker Compose configuration file.

## Functionality
1. Enter text into the input field in the frontend.
2. Click "Analyze" to get the sentiment score of the text.
3. View stored data and sentiment scores on the frontend.

## Stopping the Application
To stop the application, run:
```bash
docker-compose down
```

## Author
Your Name or GitHub Profile