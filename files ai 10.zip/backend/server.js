const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const Sentiment = require('sentiment');
const cors = require('cors');

// Initialize Express app
const app = express();
const port = 5000;
const sentiment = new Sentiment();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MongoDB Model
const DataSchema = new mongoose.Schema({
  text: String,
  sentimentScore: Number,
});

const Data = mongoose.model('Data', DataSchema);

// MongoDB Connection
mongoose.connect('mongodb://mongo:27017/mern-ai-db', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Routes
app.get('/data', async (req, res) => {
  const data = await Data.find();
  res.json(data);
});

app.post('/analyze', async (req, res) => {
  const { text } = req.body;
  const analysis = sentiment.analyze(text);
  const newData = new Data({ text, sentimentScore: analysis.score });
  await newData.save();
  res.json({ text, sentimentScore: analysis.score });
});

// Start server
app.listen(port, () => {
  console.log(`Backend running on http://localhost:${port}`);
});